from typing import Dict
from models import Candidate, JobDescription

parsed_jd_store: Dict[str, JobDescription] = {}
parsed_candidates_store: Dict[str, Candidate] = {}
